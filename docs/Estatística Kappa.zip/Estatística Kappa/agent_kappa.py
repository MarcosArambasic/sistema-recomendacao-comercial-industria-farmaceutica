import pandas as pd
import requests
from bs4 import BeautifulSoup
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
import os

#----------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------------------------------------#

# CHAVE DA OPENAI
os.environ["OPENAI_API_KEY"] = "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"

# INICIALIZA O LLM
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# TEMPLATE DO PROMPT 
prompt_template = PromptTemplate(
    input_variables=["texto_noticia"],
    template="""
    Você é um especialista em inteligência de mercado na indústria farmacêutica.
    Leia a notícia abaixo e avalie o impacto que os fatos relatados terão sobre a VENDA E DEMANDA DE MEDICAMENTOS PARA DIABETES.
    
    Notícia:
    {texto_noticia}
    
    Regras de Classificação:
    - ALTO: Impacto direto, imediato ou em larga escala nas vendas, tratamentos, regulamentação ou perfil de pacientes com diabetes.
    - MÉDIO: Impacto indireto, em longo prazo, ou que afeta a saúde de forma geral podendo respingar no mercado de diabetes.
    - BAIXO: Nenhuma relação com diabetes, saúde metabólica ou impacto nulo nas vendas.
    
    Responda APENAS com uma das três palavras: ALTO, MÉDIO ou BAIXO. Não inclua nenhuma outra palavra ou pontuação.
    """
)

# CHAIN DO LANGCHAIN
chain = prompt_template | llm

def extrair_texto_url(url):
    """Acessa a URL e extrai o texto principal da notícia."""
    try:
        # EVITAR BLOQUEIOS 
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        # EXTRAI PARÁGRAFOS
        paragrafos = soup.find_all('p')
        texto = ' '.join([p.get_text() for p in paragrafos])
        
        # LIMITAR O TEXTO
        return texto[:4000]
    except Exception as e:
        print(f"Erro ao acessar {url}: {e}")
        return None

def processar_avaliacoes(caminho_arquivo):
    print("Carregando planilha...")
    df = pd.read_excel(caminho_arquivo)
    
    # PADRONIZAÇÃO
    df.columns = df.columns.str.lower().str.strip()
    
    for index, row in df.iterrows():
        aval_mendes = str(row['classificacao mendes']).strip().upper()
        aval_guilherme = str(row['classificacao guilherme']).strip().upper()
        url = row['url']
        
        # MANTÉM RESULTADO SE AVALIAÇÕES FOREM IGUAIS
        if aval_mendes == aval_guilherme:
            df.at[index, 'classificacao kappa'] = aval_mendes
            print(f"Linha {index}: Acordo ({aval_mendes}).")
            
        # EM DIVERGÊNCIA, ACIONA O LLM PARA DESEMPATE
        else:
            print(f"Linha {index}: Divergência ({aval_mendes} vs {aval_guilherme}). Acionando LLM...")
            texto_noticia = extrair_texto_url(url)
            
            if texto_noticia:
                # CHAMA O MODELO DE IA
                resposta = chain.invoke({"texto_noticia": texto_noticia})
                decisao_ia = resposta.content.strip().upper()
                
                if decisao_ia in ['ALTO', 'MÉDIO', 'BAIXO']:
                    df.at[index, 'classificacao kappa'] = decisao_ia
                    print(f" -> LLM decidiu: {decisao_ia}")
                else:
                    df.at[index, 'classificacao kappa'] = "ERRO_IA"
                    print(f" -> LLM retornou valor inválido: {decisao_ia}")
            else:
                df.at[index, 'classificacao kappa'] = "ERRO_URL"
                print(" -> Falha ao ler a notícia.")

    arquivo_saida = "avaliacoes_desempatadas.xlsx"
    df.to_excel(arquivo_saida, index=False)
    print(f"\nProcesso concluído! Arquivo salvo como: {arquivo_saida}")

#----------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------------------------------------#

if __name__ == "__main__":
    nome_do_arquivo = "Classificação_de_notícias_v3.xlsx" 
    processar_avaliacoes(nome_do_arquivo)